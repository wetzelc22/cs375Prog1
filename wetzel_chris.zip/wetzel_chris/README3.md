In order to compile program3 just do 'make program3' to compile it and to run it 'make run3' will execute ./program3 filex.txt filey.txt output3.txt.
