In order to compile program2 just do 'make program2' to compile it and to run it 'make run2' will execute ./program2 filex.txt filey.txt output2.txt.
