In order to compile program1 just do 'make program1' to compile it and to run it 'make run1' will execute ./program1 filex.txt filey.txt output1.txt.
